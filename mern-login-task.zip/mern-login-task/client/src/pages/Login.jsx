import React, { useState } from 'react';
import axios from 'axios';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:5000/api/login', {
        email,
        password
      });
      setMsg(res.data.message);
    } catch (err) {
      setMsg('Invalid Credentials');
    }
  };

  return (
    <div style={{ maxWidth: '400px', margin: '100px auto', padding: '20px', border: '1px solid #ccc', borderRadius: 10 }}>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <input
          style={{ width: '100%', padding: 10, margin: '10px 0' }}
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          style={{ width: '100%', padding: 10, margin: '10px 0' }}
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button style={{ width: '100%', padding: 10 }} type="submit">Login</button>
      </form>
      <p>{msg}</p>
    </div>
  );
};

export default Login;