const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

// Dummy user
const dummyUser = {
  email: "test@example.com",
  password: "123456"
};

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  if (email === dummyUser.email && password === dummyUser.password) {
    res.json({ message: "Login Successful ✅" });
  } else {
    res.status(401).json({ message: "Invalid Credentials ❌" });
  }
});

app.listen(5000, () => {
  console.log("Backend running on http://localhost:5000");
});