# MERN Login Task

This is a demo MERN stack login page using dummy data.

## Run Instructions

### 1. Backend (Express)
```
cd server
npm install
node index.js
```

### 2. Frontend (React)
```
cd client
npm install
npm start
```

Try logging in with:
- Email: `test@example.com`
- Password: `123456`